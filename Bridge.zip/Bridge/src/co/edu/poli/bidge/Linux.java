package co.edu.poli.bidge;

public class Linux implements SistemaOperativo {
    public void crearVentana(String tipo) {
        // crear ventana en Linux
    }
    
    public void cerrarVentana(String tipo) {
        // cerrar ventana en Linux
    }
    
    public void redimensionarVentana(String tipo, int ancho, int alto) {
        // redimensionar ventana en Linux
    }
}
