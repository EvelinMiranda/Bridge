package co.edu.poli.bidge;

public class MacOS implements SistemaOperativo {
    public void crearVentana(String tipo) {
        // crear ventana en MacOS
    }
    
    public void cerrarVentana(String tipo) {
        // cerrar ventana en MacOS
    }
    
    public void redimensionarVentana(String tipo, int ancho, int alto) {
        // redimensionar ventana en MacOS
    }
}

