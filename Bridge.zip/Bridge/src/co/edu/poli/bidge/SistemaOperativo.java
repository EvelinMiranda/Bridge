package co.edu.poli.bidge;

public interface SistemaOperativo {
	
public void crearVentana(String tipo);
    
    public void cerrarVentana(String tipo);
    
    public void redimensionarVentana(String tipo, int ancho, int alto);


}
