package co.edu.poli.bidge;

public class Windows implements SistemaOperativo {
    public void crearVentana(String tipo) {
        // crear ventana en Windows
    }
    
    public void cerrarVentana(String tipo) {
        // cerrar ventana en Windows
    }
    
    public void redimensionarVentana(String tipo, int ancho, int alto) {
        // redimensionar ventana en Windows
    }
}

